//
//  TESTApp.swift
//  TEST
//
//  Created by MacBook Pro on 4/25/21.
//

import SwiftUI

@main
struct TESTApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
